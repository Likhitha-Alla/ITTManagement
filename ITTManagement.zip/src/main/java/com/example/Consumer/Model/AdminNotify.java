package com.example.Consumer.Model;

public class AdminNotify {
	
	
	@Override
	public String toString() {
		return "AdminNotify [ticketId=" + ticketId + ", empId=" + empId + ", selectRemedy="
				+ selectRemedy + ", information=" + information + ", Requestdocument=" + Requestdocument + ",ticketStatus="+ ticketStatus +"]";
	}
	private int ticketId;
	private String empId;
	private String selectRemedy;
	private String information;
	private String Requestdocument;
	private String ticketStatus;
	public int getTicketId() {
		return ticketId;
	}
	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getSelectRemedy() {
		return selectRemedy;
	}
	public void setSelectRemedy(String selectRemedy) {
		this.selectRemedy = selectRemedy;
	}
	public String getInformation() {
		return information;
	}
	public void setInformation(String information) {
		this.information = information;
	}
	public String getRequestdocument() {
		return Requestdocument;
	}
	public void setRequestdocument(String requestdocument) {
		Requestdocument = requestdocument;
	}
	public String getTicketStatus() {
		return ticketStatus;
	}
	public void setTicketStatus(String ticketStatus) {
		this.ticketStatus = ticketStatus;
	}

}
