package com.example.Consumer.Model;

public class UserFeedbackDetails {

	
	@Override
	public String toString() {
		return "RaiseGsd [empId=" + empId + ", ticketId=" + ticketId + ", reviewdescription="
				+ reviewdescription + ", ratings=" + ratings + "]";
	}
	private String empId;
	private int ticketId;
	private String reviewdescription;
	private String ratings;
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public int getTicketId() {
		return ticketId;
	}
	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}
	public String getReviewdescription() {
		return reviewdescription;
	}
	public void setReviewdescription(String reviewdescription) {
		this.reviewdescription = reviewdescription;
	}
	public String getRatings() {
		return ratings;
	}
	public void setRatings(String ratings) {
		this.ratings = ratings;
	}
	
	
}
