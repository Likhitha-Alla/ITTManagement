package com.example.Consumer.Model;

public class RaiseGsd {
	@Override
	public String toString() {
		return "RaiseGsd [selectRemedy=" + selectRemedy + ", description1=" + description1 + ", contactNumber="
				+ contactNumber + ", pcNumber=" + pcNumber + ", gsdnuber=" + gsdnuber + ",empId="+ empId +"]";
	}
	private String selectRemedy;
	private String description1;
	private String contactNumber;
	private String pcNumber;
	private int gsdnuber;
	private String empId;
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getSelectRemedy() {
		return selectRemedy;
	}
	public void setSelectRemedy(String selectRemedy) {
		this.selectRemedy = selectRemedy;
	}
	public String getDescription1() {
		return description1;
	}
	public void setDescription1(String description1) {
		this.description1 = description1;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getPcNumber() {
		return pcNumber;
	}
	public void setPcNumber(String pcNumber) {
		this.pcNumber = pcNumber;
	}
	public int getGsdnuber() {
		return gsdnuber;
	}
	public void setGsdnuber(int gsdnuber) {
		this.gsdnuber = gsdnuber;
	}
	
	

}
