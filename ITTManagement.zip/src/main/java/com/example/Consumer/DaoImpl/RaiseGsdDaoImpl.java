package com.example.Consumer.DaoImpl;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;



@Component
public class RaiseGsdDaoImpl {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	
	public Boolean remedyUser(String selectRemedy, String description1 , String contactNo, String pcno,String empId) {
		int flag;
		try {
			//System.out.println(selectRemedy);
			//System.out.println(description1);
			//System.out.println(contactNo);
			
			flag=jdbcTemplate.update("insert into raisegsd(selectRemedy,description1,contactNumber,pcNumber,empId) values(?,?,?,?,?)",selectRemedy,description1,contactNo,pcno,empId);
			if(flag>0)
				return true;
		}
		catch (Exception e) {
			return true;
		}
		
		return false;
	}

}
