package com.example.Consumer.DaoImpl;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.example.Consumer.Dao.RegistrationDao;

@Component
public class RegistrationDaoImpl implements RegistrationDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public Boolean registerUser(String fname, String lastname, String des, String empId, String seatno, String pcno,String ip,
			String contactNo, String password) {
		int flag;
		try {
			flag=jdbcTemplate.update("insert into users values(?,?,?,?,?,?,?,?,?)", fname,lastname,des,empId,seatno,pcno,ip,contactNo,password);
			if(flag>0)
				return true;
		}
		catch (Exception e) {
			return true;
		}
		
		return false;
	}
}
