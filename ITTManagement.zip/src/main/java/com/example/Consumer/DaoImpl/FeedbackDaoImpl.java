package com.example.Consumer.DaoImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.example.Consumer.Dao.FeedBackDao;

@Component
public class FeedbackDaoImpl implements FeedBackDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public Boolean feedback(String empId, int ticketId , String reviewdescription, String ratings) {
		int flag;
		try {
			
			flag=jdbcTemplate.update("insert into review(empId,ticketId,reviewdescription,ratings) values(?,?,?,?)",empId,ticketId,reviewdescription,ratings);
			if(flag>0)
				return true;
		}
		catch (Exception e) {
			return true;
		}
		
		return false;
	}

}
