package com.example.Consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GsdManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(GsdManagementApplication.class, args);
	}

}
