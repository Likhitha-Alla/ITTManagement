package com.example.Consumer.BO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Consumer.DaoImpl.UserFeedbackDetailsDaoImpl;
import com.example.Consumer.Model.UserFeedbackDetails;

@Service
public class UserFeedbackDetailsService {
	@Autowired
	UserFeedbackDetailsDaoImpl userFeedbackDetailsDaoImpl;
	
	public List<UserFeedbackDetails> getAllRequests() {
		return userFeedbackDetailsDaoImpl.getAllRequests();
	}


}
