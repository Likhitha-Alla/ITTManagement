package com.example.Consumer.BO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Consumer.DaoImpl.FeedbackDaoImpl;

@Service
public class FeedBackService {
	@Autowired
	FeedbackDaoImpl feedBackDaoImpl;
	public Boolean feedback(String empId, int ticketId , String reviewdescription, String ratings) {
		return feedBackDaoImpl.feedback(empId, ticketId, reviewdescription, ratings);
	}


}
