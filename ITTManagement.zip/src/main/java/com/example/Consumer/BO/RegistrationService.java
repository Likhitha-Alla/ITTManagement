package com.example.Consumer.BO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Consumer.DaoImpl.RegistrationDaoImpl;

@Service
public class RegistrationService {
	@Autowired
	RegistrationDaoImpl registrationDaoImpl;

	public Boolean registerUser(String fname, String lastname, String des, String empId, String seatno, String pcno,String ip,
			String contactNo, String password){
		
		return registrationDaoImpl.registerUser(fname, lastname, des, empId, seatno, pcno,ip, contactNo, password);
	}
}
