package com.example.Consumer.BO;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.example.Consumer.DaoImpl.UserNotifyDaoImpl;
import com.example.Consumer.Model.AdminNotify;

@Service
public class UserNotifyService {
	
	@Autowired
	UserNotifyDaoImpl userNotifyDaoImpl;
	public AdminNotify getDetailsById(String empid) {
		return userNotifyDaoImpl.getDetailsById(empid);
	}

}
