package com.example.Consumer.Dao;

import java.util.List;

import com.example.Consumer.Model.UserFeedbackDetails;

public interface UserFeedbackDetailsDao {
	public List<UserFeedbackDetails> getAllRequests();

}
