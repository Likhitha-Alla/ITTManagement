package com.example.Consumer.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.Consumer.BO.RaiseGsdService;

@Controller
public class RaiseGsdController {

	@Autowired
	RaiseGsdService remedyService;
	@RequestMapping(value = "/remedyUser", method = RequestMethod.POST)
	public String remedyUser(@RequestParam String gsd,@RequestParam String w3review,@RequestParam String IN,@RequestParam String pcno,String empId) {
		if(remedyService.remedyUser(gsd, w3review, IN, pcno,empId)) {
			return "index";
		}
		return "gsdcreate";
	}
	
	@RequestMapping(value = "/gsdcreate", method = RequestMethod.GET)
	public String gsdregs() {
		return "gsdcreate";
	}
}
