package com.example.Consumer;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.springframework.beans.factory.annotation.Autowired;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.Consumer.BO.LoginService;
@SpringBootTest
public class GsdManagementApplicationTests {

	@Autowired
	LoginService loginService;
	/*Test1*/
	@Test
	public void test_User_Valid_ValidData() {
		boolean isValid = loginService.validate("892656", "Admin@123");
		assertTrue(isValid, "check logic for validate user");
	}
	/*Test2*/
	
	@Test
	public void test_User_Valid_InValidData() {
		boolean isValid = loginService.validate("892656", "Admin@12354");
		assertFalse(isValid, "check logic for validate user");
	}
	/*Test3*/
	@Test
	public void test_Admin_Valid_ValidData() {
		boolean isValid = loginService.validate1("admin123", "admin@123");
		assertTrue(isValid, "check logic for validate admin");
	}
	
	/*Test4*/
	
	@Test
	public void test_Admin_Valid_InValidData() {
		boolean isValid = loginService.validate1("admin", "Admin@1234");
		assertFalse(isValid, "check logic for invalidate admin");
	}
	
	/*Test5*/
	@Test
	public void test_getPcNumber_Test1() {
		String expectedValue = "PC1234";
		String actualValue = loginService.getPcNumber("892656");
		assertEquals(expectedValue, actualValue,"Fail to obtains PC Number");
	}
	
	/*Test6*/
	@Test
	public void test_getContactNumber_Test() {
		String expectedValue = "9876543218";
		String actualValue = loginService.getContactNumber("892652");
		assertEquals(expectedValue, actualValue,"Fail to obtains PC Number");
	}
	
}
	